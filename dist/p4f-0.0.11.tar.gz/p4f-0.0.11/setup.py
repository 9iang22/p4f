#coding=utf8
from setuptools import setup
import setuptools
setup(name='p4f',
      version='0.0.11',
      description='pwntools helper',
      url='http://github.com',
      author='Msk',
      author_email='moskong@qq.com',
      license='MIT',
      packages=setuptools.find_packages(),
      zip_safe=False)



