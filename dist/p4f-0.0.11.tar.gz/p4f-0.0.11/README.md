# My pwntools helper

### Usage:
~~~python
from p4f import *
p = core.Pwn("./pwn")
